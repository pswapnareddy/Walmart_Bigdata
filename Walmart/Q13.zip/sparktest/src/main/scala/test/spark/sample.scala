package com.basic

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.{StructType,StructField,StringType};

//Assign column names to DataFrame
object sample {
  def main(args: Array[String]) ={

    System.setProperty("hadoop.home.dir", "C:\\hadoop\\");

    //spark 2
    val sparkSession = SparkSession.builder
      .master("local")
      .appName("my-spark-app")
      .getOrCreate()

    //read csv file
    val salesDf = sparkSession.read.csv("data/sales.txt").toDF()
    //check schema
    salesDf.printSchema()
    //check data
    salesDf.show()



  }
}


